# Internal utilities module
