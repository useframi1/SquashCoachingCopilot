# Internal rule-based model module
