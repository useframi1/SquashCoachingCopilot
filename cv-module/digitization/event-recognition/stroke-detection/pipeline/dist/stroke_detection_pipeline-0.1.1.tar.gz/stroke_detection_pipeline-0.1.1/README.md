# Stroke Detection Pipeline

LSTM-based stroke detection pipeline for squash/tennis videos. Processes player keypoints and predicts stroke types (forehand, backhand, etc.) using a sliding window approach.

## Features

- **Real-time stroke detection** from player keypoints
- **Multi-player support** with independent tracking buffers
- **Sliding window prediction** using LSTM neural network
- **Automatic keypoint normalization** relative to body proportions
- **Cooldown mechanism** to prevent repetitive predictions
- **Configurable parameters** via JSON config file

## Installation

```bash
pip install -e .
```

## Quick Start

```python
from stroke_detection_pipeline.stroke_detector import StrokeDetector
import numpy as np

# Initialize detector (uses config.json by default)
detector = StrokeDetector(
    model_path="stroke_detection_pipeline/model/weights/lstm_model.pt"
)

# Prepare player keypoints (COCO format: 17 keypoints with x, y coordinates)
player_keypoints = {
    1: np.array([  # Player 1
        [120, 50],   # nose
        [115, 45],   # left_eye
        [125, 45],   # right_eye
        # ... (17 keypoints total)
    ]),
    2: np.array([...])  # Player 2
}

# Process frame and get predictions
predictions = detector.process_frame(player_keypoints)

# Output: {player_id: {'stroke': str, 'confidence': float}}
for player_id, pred in predictions.items():
    print(f"Player {player_id}: {pred['stroke']} ({pred['confidence']:.2f})")
```

## Input Format

The `process_frame()` method accepts keypoints in two formats:

### 1. COCO Format (Tensor/Array)
```python
keypoints = np.array([
    [x, y],  # 0: nose
    [x, y],  # 1: left_eye
    [x, y],  # 2: right_eye
    [x, y],  # 3: left_ear
    [x, y],  # 4: right_ear
    [x, y],  # 5: left_shoulder
    [x, y],  # 6: right_shoulder
    [x, y],  # 7: left_elbow
    [x, y],  # 8: right_elbow
    [x, y],  # 9: left_wrist
    [x, y],  # 10: right_wrist
    [x, y],  # 11: left_hip
    [x, y],  # 12: right_hip
    [x, y],  # 13: left_knee
    [x, y],  # 14: right_knee
    [x, y],  # 15: left_ankle
    [x, y],  # 16: right_ankle
])
```

### 2. Dictionary Format
```python
keypoints = {
    'x_left_shoulder': 100, 'y_left_shoulder': 200,
    'x_right_shoulder': 150, 'y_right_shoulder': 200,
    # ... (all 12 relevant keypoints)
}
```

## Configuration

Edit `stroke_detection_pipeline/config.json` to customize parameters:

```json
{
  "model": {
    "model_path": "stroke_detection_pipeline/model/weights/lstm_model.pt",
    "device": "auto"
  },
  "detection": {
    "window_size": 15,
    "confidence_threshold": 0.5,
    "cooldown_frames": 5
  },
  "keypoints": {
    "relevant_indices": [5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16],
    "relevant_names": [
      "left_shoulder", "right_shoulder",
      "left_elbow", "right_elbow",
      "left_wrist", "right_wrist",
      "left_hip", "right_hip",
      "left_knee", "right_knee",
      "left_ankle", "right_ankle"
    ]
  },
  "normalization": {
    "method": "hip_torso",
    "min_torso_length": 1e-6
  }
}
```

### Parameters

- **window_size**: Number of frames required for prediction (default: 15)
- **confidence_threshold**: Minimum confidence to report a stroke (default: 0.5)
- **cooldown_frames**: Frames to wait before reporting same stroke again (default: 5)
- **device**: Computing device - "auto", "cuda", or "cpu" (default: "auto")

## Pipeline Architecture

```
Input Keypoints (COCO format)
    �
Extract Relevant Keypoints (12 points)
    �
Normalize (relative to hip center & torso length)
    �
Buffer Management (sliding window)
    �
LSTM Model Prediction
    �
Confidence Thresholding
    �
Cooldown Check
    �
Output: {player_id: {'stroke': str, 'confidence': float}}
```

## How It Works

1. **Keypoint Extraction**: Extracts 12 relevant keypoints from COCO format (shoulders, elbows, wrists, hips, knees, ankles)

2. **Normalization**: Normalizes keypoints relative to:
   - Hip center (origin)
   - Torso length (scale factor)

3. **Buffering**: Maintains a sliding window buffer of normalized keypoints for each player

4. **Prediction**: When buffer reaches `window_size`:
   - Feeds last N frames to LSTM model
   - Gets stroke prediction and confidence
   - Applies confidence threshold

5. **Cooldown**: Prevents repetitive predictions of the same stroke within `cooldown_frames`

## Output Format

```python
{
    1: {  # Player 1
        'stroke': 'backhand',
        'confidence': 0.85
    },
    2: {  # Player 2
        'stroke': 'forehand',
        'confidence': 0.72
    }
}
```

Possible stroke values:
- `"forehand"` - Forehand stroke detected
- `"backhand"` - Backhand stroke detected
- `"neither"` - No stroke or low confidence

## Project Structure

```
stroke_detection_pipeline/
   config.json                 # Configuration file
   stroke_detector.py          # Main pipeline class
   utils.py                    # Utility functions
   model/
       lstm_classifier.py      # LSTM model architecture
       weights/
           lstm_model.pt       # Trained model weights
```

## Requirements

- Python >= 3.7
- numpy
- torch
- opencv-python

## Example

See `example.py` for a complete usage example.

## License

MIT License

## Author

Youssef Elhagg (yousseframi@aucegypt.edu)
